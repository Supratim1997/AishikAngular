import { BrowserModule } from '@angular/platform-browser';  
import { NgModule } from '@angular/core';  
import { HttpClientModule } from '@angular/common/http';  
// import ReactiveFormsModule for reactive form  
import { ReactiveFormsModule } from '@angular/forms';  
  
// import module for Routing.  
import { RouterModule } from '@angular/router';  
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';  
import { LoginComponent } from './login/login.component';  
import { HomeComponent } from './home/home.component';  
import { AdminService } from './services/admin.service';  
  
@NgModule({  
  declarations: [  
    AppComponent,  
    LoginComponent,  
    HomeComponent,  
  ],  
  imports: [  
    BrowserModule,  
    ReactiveFormsModule,  
    HttpClientModule, 
    FormsModule, 
    RouterModule.forRoot([  
      {  
        path : '',  
        component : LoginComponent   
      },  
      {  
        path : 'home',  
        component : HomeComponent    
      }
    ])  
  
  ],  
  providers: [  
    AdminService  
  ],  
  bootstrap: [AppComponent]  
})  
export class AppModule { }  