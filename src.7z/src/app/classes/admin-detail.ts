export class AdminDetail {  
    emailId : string;  
    name : string;  
    password : string ;  
    role : string;  
} 