import { PackageDetails } from './package-details';

describe('PackageDetails', () => {
  it('should create an instance', () => {
    expect(new PackageDetails()).toBeTruthy();
  });
});
