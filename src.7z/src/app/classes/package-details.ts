export class PackagerDetails {

    constructor(
      public PackageId: number,
      public PackageName: string,
      public PackageCategory: string,
      public PackageDescription: string,
      public TourType: string
    ) {  }
  
  }