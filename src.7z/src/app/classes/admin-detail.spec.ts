import { AdminDetail } from './admin-detail';

describe('AdminDetail', () => {
  it('should create an instance', () => {
    expect(new AdminDetail()).toBeTruthy();
  });
});
