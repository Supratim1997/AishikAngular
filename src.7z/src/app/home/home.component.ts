import { Component, OnInit } from '@angular/core';

import { PackagerDetails } from '../classes/package-details'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  packageCategory = ['Adventure', 'nature',
            'Family', 'Romantic'];

  model = new PackagerDetails(102030, 'PackageName', this.packageCategory[0], 'Package Description', 'Domestic');

  submitted = false;

  onSubmit() { this.submitted = true; }

  constructor() { }

  ngOnInit(): void {
  }

  get diagnostic() { return JSON.stringify(this.model); }


}
